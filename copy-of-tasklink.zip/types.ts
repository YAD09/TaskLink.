
export enum UserRole {
  STUDENT = 'STUDENT',
  ADMIN = 'ADMIN'
}

export enum TaskStatus {
  OPEN = 'OPEN',
  ASSIGNED = 'ASSIGNED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED',
  PAID = 'PAID',
  CANCELLED = 'CANCELLED',
  DISPUTED = 'DISPUTED'
}

export enum OfferStatus {
  PENDING = 'PENDING',
  ACCEPTED = 'ACCEPTED',
  REJECTED = 'REJECTED'
}

export enum TaskType {
  ONLINE = 'ONLINE',
  OFFLINE = 'OFFLINE'
}

export enum VerificationStatus {
  NONE = 'NONE',
  PENDING = 'PENDING',
  VERIFIED = 'VERIFIED',
  REJECTED = 'REJECTED'
}

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  password?: string;
  college: string;
  verified: boolean; // Legacy flag, kept for backward compat, derived from verificationStatus
  verificationStatus: VerificationStatus;
  verificationDocUrl?: string; // URL/Base64 of ID card
  role: UserRole;
  balance: number;
  escrowBalance: number;
  rating: number;
  reviewsCount: number; // For calculating average
  tasksCompleted: number;
  avatarUrl?: string;
}

export interface Comment {
  id: string;
  taskId?: string;
  userId: string;
  username: string;
  content: string;
  createdAt: string;
}

export interface Offer {
  id: string;
  taskId: string;
  userId: string;
  doerName: string;
  doerRating: number;
  message: string;
  price: number;
  status: OfferStatus;
  createdAt: string;
}

export interface Attachment {
  id: string;
  name: string;
  url: string;
  type: 'IMAGE' | 'DOCUMENT';
}

export interface Review {
  id: string;
  reviewerId: string;
  revieweeId: string;
  rating: number; // 1-5
  comment: string;
  createdAt: string;
}

export interface Task {
  id: string;
  posterId: string;
  posterName: string;
  title: string;
  description: string;
  category: string;
  budget: number;
  deadline: string;
  status: TaskStatus;
  type: TaskType;
  location?: string;
  coordinates?: { lat: number; lng: number };
  createdAt: string;
  tags: string[];
  executorId?: string;
  submissionUrl?: string;
  offers: Offer[];
  comments: Comment[];
  attachments?: Attachment[];
  reviews?: Review[];
}

export interface Transaction {
  id: string;
  userId: string;
  type: 'DEPOSIT' | 'WITHDRAWAL' | 'ESCROW_LOCK' | 'PAYMENT_RELEASE' | 'REFUND' | 'DISPUTE_RESOLUTION';
  amount: number;
  date: string;
  description: string;
  status: 'SUCCESS' | 'PENDING' | 'FAILED';
}

export interface Notification {
  id: string;
  userId: string;
  type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ERROR';
  title: string;
  message: string;
  link?: string;
  isRead: boolean;
  createdAt: string;
}

export interface AcceptOfferPayload {
  taskId: string;
  offerId: string;
  executorId: string;
}

export interface CancelAndRefundPayload {
  taskId: string;
  userId: string;
  reason?: string;
}
